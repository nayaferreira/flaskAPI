from flask import Flask, render_template
import urllib.request
import json
import geopy.distance

app = Flask('main')


OW_API_KEY = 'c3b2505b75e659e1f1029d0050d66fa6'
BDC_API_KEY = 'bdc_d32eb52242754d9a9bf521274a2222d6'

# Location coordinates:
YOUR_LATITUDE = 46.486825
YOUR_LONGITUDE = -80.904289

def iss_loc():
    url = 'http://api.open-notify.org/iss-now.json'
    request = urllib.request.urlopen(url)
    result = json.loads(request.read())

    lat = result['iss_position']['latitude']
    lon = result['iss_position']['longitude']
    print("ISS Location: https://google.com/maps/place/" + lat + "+" + lon)
    return float(lat), float(lon)

def get_weather(lat, lon):
    url = f'https://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&units=metric&appid={OW_API_KEY}'
    request = urllib.request.urlopen(url)
    result = json.loads(request.read())
    temperature = result['main']['temp']
    print(f"Weather at ISS Location: {temperature}°C")
    return temperature

def get_address(lat, lon):
    url = f'https://api-bdc.net/data/reverse-geocode?latitude={lat}&longitude={lon}&localityLanguage=en&key={BDC_API_KEY}'
    request = urllib.request.urlopen(url)
    result = json.loads(request.read())
    address = result['localityInfo']['administrative'][0]['name']
    print(f"Address Below ISS: {address}")
    return address

def get_country_flag(country_code):
    url = f'https://restcountries.com/v3.1/alpha/{country_code}'
    request = urllib.request.urlopen(url)
    result = json.loads(request.read())
    flag_url = result[0]['flags']['png']
    print(f"Country Flag URL: {flag_url}")
    return flag_url

def calculate_distance(lat1, lon1, lat2, lon2):
    coords_1 = (lat1, lon1)
    coords_2 = (lat2, lon2)
    distance = round(geopy.distance.distance(coords_1, coords_2).km, 2)
    print(f"Distance from Your Location to ISS: {distance} km")
    return distance

@app.route('/')
def index():
    iss_lat, iss_lon = iss_loc()
    weather = get_weather(iss_lat, iss_lon)
    address = get_address(iss_lat, iss_lon)
    country_code = 'US'  #fixed country code if the reverse geocode API does not return it
    flag_url = get_country_flag(country_code)
    distance = calculate_distance(YOUR_LATITUDE, YOUR_LONGITUDE, iss_lat, iss_lon)
    return render_template('index.html', iss_lat=iss_lat, iss_lon=iss_lon, weather=weather, address=address, flag_url=flag_url, distance=distance)

app.run(host='0.0.0.0', port=81, debug=True)